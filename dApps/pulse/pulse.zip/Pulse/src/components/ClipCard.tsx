import { Heart, MessageCircle, Share2, Zap } from 'lucide-react'
import { useState } from 'react'

interface ClipCardProps {
  id: string
  title: string
  creator: string
  thumbnail: string
  duration: string
  views: number
  likes: number
  category: 'gaming' | 'sports' | 'streaming'
  onTokenize: () => void
}

export function ClipCard({ 
  id, 
  title, 
  creator, 
  thumbnail, 
  duration, 
  views, 
  likes,
  category,
  onTokenize 
}: ClipCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [likeCount, setLikeCount] = useState(likes)

  const toggleLike = () => {
    setIsLiked(!isLiked)
    setLikeCount(isLiked ? likeCount - 1 : likeCount + 1)
  }

  const categoryColor = {
    gaming: 'bg-purple-600/30 text-purple-300',
    sports: 'bg-orange-600/30 text-orange-300',
    streaming: 'bg-cyan-600/30 text-cyan-300',
  }

  return (
    <article className="group rounded-lg overflow-hidden border border-purple-700/20 hover:border-purple-600/40 bg-slate-900/40 hover:bg-slate-900/60 transition-all hover:shadow-[0_0_20px_rgba(153,69,255,0.1)]">
      {/* Thumbnail */}
      <div className="relative overflow-hidden bg-slate-800 aspect-video">
        <img 
          src={thumbnail} 
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button 
            onClick={onTokenize}
            className="px-4 py-2 rounded-lg bg-purple-600 text-white font-mono font-bold text-sm uppercase flex items-center gap-2 hover:bg-purple-700 transition"
          >
            <Zap size={16} />
            Tokenize Now
          </button>
        </div>
        
        {/* Duration badge */}
        <div className="absolute bottom-2 right-2 bg-black/80 px-2 py-1 rounded text-xs font-mono text-white">
          {duration}
        </div>

        {/* Category badge */}
        <div className={`absolute top-2 right-2 px-3 py-1 rounded text-xs font-bold uppercase ${categoryColor[category]}`}>
          {category}
        </div>
      </div>

      {/* Info */}
      <div className="p-4 space-y-3">
        <div>
          <h3 className="font-bold text-slate-100 line-clamp-2 group-hover:text-purple-300 transition">
            {title}
          </h3>
          <p className="text-sm text-slate-400 mt-1">by {creator}</p>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-4 text-xs text-slate-400 font-mono">
          <span>{views.toLocaleString()} views</span>
          <span>•</span>
          <span>ID: {id.slice(0, 8)}</span>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 pt-2 border-t border-purple-700/10">
          <button
            onClick={toggleLike}
            className={`flex items-center gap-1 px-3 py-1.5 rounded hover:bg-purple-500/20 transition text-sm ${
              isLiked ? 'text-red-400' : 'text-slate-400 hover:text-red-400'
            }`}
          >
            <Heart size={16} fill={isLiked ? 'currentColor' : 'none'} />
            {likeCount}
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-purple-500/20 transition text-slate-400 hover:text-slate-100 text-sm">
            <MessageCircle size={16} />
          </button>
          <button className="flex items-center gap-1 px-3 py-1.5 rounded hover:bg-purple-500/20 transition text-slate-400 hover:text-slate-100 text-sm">
            <Share2 size={16} />
          </button>
        </div>
      </div>
    </article>
  )
}
