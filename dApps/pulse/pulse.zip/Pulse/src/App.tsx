import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { LandingPage } from './pages/LandingPage'
import { HomePage } from './pages/HomePage'
import { Navbar } from './components/Navbar'
import './App.css'

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-slate-950 overflow-x-hidden">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route 
            path="/app" 
            element={
              <>
                <Navbar />
                <HomePage />
              </>
            } 
          />
        </Routes>
      </div>
    </Router>
  )
}
