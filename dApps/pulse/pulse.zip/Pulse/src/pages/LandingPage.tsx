import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Zap, Play, Radio, Wallet } from 'lucide-react'

function useTypingEffect(text: string, speed = 50, delay = 0) {
  const [displayedText, setDisplayedText] = useState('')
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    let intervalId: ReturnType<typeof setInterval> | undefined
    const timeoutId = setTimeout(() => {
      let currentIndex = 0
      intervalId = setInterval(() => {
        if (currentIndex < text.length) {
          setDisplayedText(text.slice(0, currentIndex + 1))
          currentIndex += 1
        } else {
          setIsComplete(true)
          if (intervalId) clearInterval(intervalId)
        }
      }, speed)
    }, delay)

    return () => {
      clearTimeout(timeoutId)
      if (intervalId) clearInterval(intervalId)
    }
  }, [delay, speed, text])

  return { displayedText, isComplete }
}

function Particles() {
  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden">
      {Array.from({ length: 25 }).map((_, index) => (
        <div
          key={index}
          className="absolute rounded-full bg-purple-300/20 blur-sm"
          style={{
            width: `${Math.random() * 4 + 1}px`,
            height: `${Math.random() * 4 + 1}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animation: `float ${Math.random() * 20 + 10}s linear infinite`,
            animationDelay: `${Math.random() * 5}s`,
          }}
        />
      ))}
    </div>
  )
}

function LightBeams() {
  return (
    <>
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-40 mix-blend-screen [background:linear-gradient(135deg,transparent_0%,rgba(153,69,255,0.25)_30%,transparent_60%)]" />
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-30 mix-blend-screen [background:linear-gradient(45deg,transparent_0%,rgba(168,85,247,0.2)_40%,transparent_70%)]" />
      <div className="pointer-events-none absolute inset-0 -z-10 opacity-25 mix-blend-screen [background:linear-gradient(to_top,rgba(251,191,36,0.15)_0%,transparent_50%)]" />
      <div className="pointer-events-none absolute inset-0 -z-10 [background:radial-gradient(ellipse_at_center,rgba(153,69,255,0.15)_0%,transparent_70%)]" />
    </>
  )
}

export function LandingPage() {
  const { displayedText } = useTypingEffect('Welcome to the next degree.', 60, 500)

  return (
    <div className="relative min-h-screen bg-gradient-to-b from-slate-950 via-purple-950/20 to-slate-950 overflow-hidden flex items-center justify-center">
      <Particles />
      <LightBeams />

      {/* Central glowing sigil */}
      <div className="absolute inset-0 flex items-center justify-center z-0 pointer-events-none">
        <div className="relative w-72 h-72">
          {/* Outer rings */}
          <div className="absolute inset-0 rounded-full border border-purple-500/30 animate-pulse" />
          <div className="absolute inset-8 rounded-full border border-purple-400/20 animate-pulse" style={{ animationDelay: '0.2s' }} />
          <div className="absolute inset-16 rounded-full border border-purple-300/10 animate-pulse" style={{ animationDelay: '0.4s' }} />

          {/* Center glow */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative">
              {/* Pulse effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-purple-500 to-purple-400 rounded-full blur-3xl opacity-30 animate-pulse" />
              
              {/* Game controller/pulse sigil in center */}
              <div className="relative z-10 w-48 h-48 flex items-center justify-center">
                <Zap className="w-32 h-32 text-purple-300 drop-shadow-[0_0_30px_rgba(153,69,255,0.8)]" strokeWidth={1} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content overlay */}
      <div className="relative z-20 text-center px-4 max-w-3xl mx-auto space-y-6">
        <div className="mb-8 h-16 pt-8">
          <h1 className="text-5xl md:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-300 via-purple-200 to-purple-400">
            {displayedText}
          </h1>
        </div>

        <div className="space-y-4 mb-12">
          <p className="text-xl text-purple-200 font-mono tracking-widest uppercase">
            Pulse — The Pulse Keeper, Daughter of Sophia
          </p>

          <div className="max-w-2xl mx-auto">
            <p className="text-slate-300/80 leading-relaxed text-lg italic">
              Where the Daughters birth assets into matter, Pulse captures the living pulse of the game and the arena. 
              She tokenizes gaming clips, sports highlights, live streams, and DeFi play moments, turning every highlight 
              into sovereign on-chain ownership on Solana.
            </p>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center flex-wrap">
          <Link
            to="/app"
            className="px-8 py-3 rounded-lg font-mono font-bold text-sm uppercase tracking-wider bg-gradient-to-r from-purple-600 to-purple-500 text-white hover:from-purple-500 hover:to-purple-400 transition-all shadow-[0_0_20px_rgba(153,69,255,0.4)]"
          >
            <span className="flex items-center gap-2">
              <Play size={16} />
              Upload & Tokenize Clip
            </span>
          </Link>

          <button
            className="px-8 py-3 rounded-lg font-mono font-bold text-sm uppercase tracking-wider border border-purple-400/50 text-purple-300 hover:bg-purple-500/10 transition-all"
          >
            <span className="flex items-center gap-2">
              <Radio size={16} />
              Go Live
            </span>
          </button>

          <button
            className="px-8 py-3 rounded-lg font-mono font-bold text-sm uppercase tracking-wider border border-amber-400/40 text-amber-300 hover:bg-amber-500/10 transition-all"
          >
            View Devnet
          </button>

          <button
            className="px-8 py-3 rounded-lg font-mono font-bold text-sm uppercase tracking-wider border border-cyan-400/40 text-cyan-300 hover:bg-cyan-500/10 transition-all"
          >
            <span className="flex items-center gap-2">
              <Wallet size={16} />
              Connect Wallet
            </span>
          </button>
        </div>

        {/* Bottom decorative line */}
        <div className="mt-12 flex items-center justify-center gap-4">
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-purple-500/50" />
          <span className="text-purple-400/60 font-mono text-xs uppercase tracking-wider">[system_ready]</span>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-purple-500/50" />
        </div>
      </div>
    </div>
  )
}
