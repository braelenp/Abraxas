import { useState } from 'react'
import { ClipFeed } from '../components/ClipFeed'
import { ClipUploadModal } from '../components/ClipUploadModal'
import { LiveStreamingSection } from '../components/LiveStreamingSection'

export function HomePage() {
  const [showUploadModal, setShowUploadModal] = useState(false)
  const [showLiveStream, setShowLiveStream] = useState(false)

  return (
    <div className="min-h-screen bg-slate-950 pt-20">
      {/* Hero section with quick actions */}
      <div className="border-b border-purple-900/30 bg-gradient-to-b from-purple-950/40 to-slate-950 py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-purple-200 mb-2">&gt; [CLIP_KEEPER] ACTIVE</h1>
              <p className="text-slate-400 text-sm font-mono">Tokenize gaming highlights • Sports moments • Live streams</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => setShowUploadModal(true)}
                className="px-6 py-2 rounded-lg bg-purple-600 text-white font-mono font-semibold text-sm uppercase tracking-wider hover:bg-purple-700 transition-all border border-purple-500/50"
              >
                + Upload Clip
              </button>
              <button
                onClick={() => setShowLiveStream(true)}
                className="px-6 py-2 rounded-lg bg-red-600/80 text-white font-mono font-semibold text-sm uppercase tracking-wider hover:bg-red-700 transition-all border border-red-500/50 animate-pulse"
              >
                Go Live
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        {showLiveStream ? (
          <LiveStreamingSection onClose={() => setShowLiveStream(false)} />
        ) : (
          <>
            {/* Clip Feed */}
            <div className="mb-12">
              <h2 className="text-xl font-bold text-purple-300 mb-6 font-mono tracking-wider uppercase">&gt; [TRENDING_CLIPS] LIVE</h2>
              <ClipFeed />
            </div>

            {/* Coming soon sections */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
              <div className="rounded-lg border border-purple-700/30 bg-purple-950/20 p-8 text-center">
                <h3 className="text-lg font-bold text-purple-300 mb-2 font-mono">📊 Community Leaderboard</h3>
                <p className="text-slate-400 text-sm">Top clip creators, highest earnings, most shared moments</p>
              </div>
              <div className="rounded-lg border border-purple-700/30 bg-purple-950/20 p-8 text-center">
                <h3 className="text-lg font-bold text-purple-300 mb-2 font-mono">🎮 Gaming Tournaments</h3>
                <p className="text-slate-400 text-sm">Tokenized esports moments, play-to-earn streaming</p>
              </div>
            </div>
          </>
        )}
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <ClipUploadModal onClose={() => setShowUploadModal(false)} />
      )}
    </div>
  )
}
